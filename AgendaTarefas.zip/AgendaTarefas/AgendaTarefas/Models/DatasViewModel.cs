﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgendaTarefas.Models
{
    public class DatasViewModel
    {
        public string Datas { get; set; }
        public string Identificadores { get; set; }
    }
}
